/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package orders;

/**
 *
 * @author sipml
 */
import java.util.Scanner;
import javax.swing.JOptionPane;
public class OrderCake {

    public static void main(String[] args) {
        OrderCake orderCake = new OrderCake();
        orderCake.processOrder();
    }

    public void processOrder() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("****** Welcome to My Cake Shop ******");
        System.out.print("How many cakes would you like to order? ");
        int numberOfCakes = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        String[] cakes = new String[numberOfCakes];
        for (int i = 0; i < numberOfCakes; i++) {
            System.out.println("You can choose Cupcakes, Occasion Cake, or Custom Cake");
            System.out.print("Enter the type of cake that you want: ");
            String cakeType = scanner.nextLine();

            switch (cakeType.toLowerCase()) {
                case "occasion":
                    cakes[i] = createOccasionCake(scanner);
                    break;
                case "custom":
                    cakes[i] = createCustomCake(scanner);
                    break;
                case "cupcake":
                    cakes[i] = createCupcake(scanner);
                    break;
                default:
                    System.out.println("Invalid cake type. Please try again.");
                    i--;  
            }
        }

        StringBuilder orderDetails = new StringBuilder("Your order details:\n");
        for (int i = 0; i < numberOfCakes; i++) {
            orderDetails.append("Cake ").append(i + 1).append(": ").append(cakes[i]).append("\n");
        }

        int confirmation = JOptionPane.showConfirmDialog(null, orderDetails.toString() + "\nDo you want to confirm your order?", "Order Confirmation", JOptionPane.YES_NO_OPTION);

        if (confirmation == JOptionPane.YES_OPTION) {
            String confirmationNumber = generateOrderNumber();
            JOptionPane.showMessageDialog(null, "Your order has been placed. Your confirmation code is " + confirmationNumber + ".", "Order Placed", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Order canceled.", "Order Canceled", JOptionPane.INFORMATION_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, "Press OK to exit.", "Exit", JOptionPane.INFORMATION_MESSAGE);
        scanner.close();
        System.exit(0);
    }
    private String createCustomCake(Scanner scanner) {
        System.out.print("Enter the flavour of the custom cake: ");
        String flavour = scanner.nextLine();

        System.out.print("Enter the number of layers (1 to 4): ");
        int layers = scanner.nextInt();
        scanner.nextLine();  

        System.out.print("Enter the size of the cake (6\", 8\", 10\", 12\"): ");
        int size = scanner.nextInt();
        scanner.nextLine();  

        return "Custom Cake - Flavour: " + flavour + ", Layers: " + layers + ", Size: " + size + "\"";
    }
    private String createOccasionCake(Scanner scanner) {
        System.out.print("Enter the flavour of the occasion cake: ");
        String flavour = scanner.nextLine();

        System.out.print("Enter the type of occasion cake (Holiday, Wedding, Birthday, Anniversary): ");
        String occasionType = scanner.nextLine();

        return "Occasion Cake - Flavour: " + flavour + ", Occasion: " + occasionType;
    }
    private String createCupcake(Scanner scanner) {
        System.out.print("Enter the flavour of the cupcake: ");
        String flavour = scanner.nextLine();

        System.out.print("Enter the count (4 or 6): ");
        int count = scanner.nextInt();
        scanner.nextLine();  
        System.out.print("Enter the weight of each cupcake (1, 2, or 3 oz): ");
        int weight = scanner.nextInt();
        scanner.nextLine();  

        return "Cupcake - Flavour: " + flavour + ", Count: " + count + ", Weight: " + weight + "oz";
    }

    private String generateOrderNumber() {
        int number = (int) (Math.random() * 90000) + 10000; 
        return String.valueOf(number);
    }
}
