/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cakes;

/**
 *
 * @author sipml
 */
public class CustomCake extends Cake {
    public int layers;
    public int size; // Diameter in inches
    public static final double BASE_PRICE = 30.0;
    public static final double LAYER_PRICE = 3.0;

    public CustomCake(String flavour, int layers, int size) {
        super(flavour);
        this.layers = layers;
        this.size = size;
    }

    @Override
    public double calculateCost() {
        cost = BASE_PRICE + (layers * LAYER_PRICE) + size;
        return cost;
    }

    @Override
    public String toString() {
        return "CustomCake{flavour='" + flavour + "', layers=" + layers +
               ", size=" + size + ", cost=" + cost + '}';
    }
}
