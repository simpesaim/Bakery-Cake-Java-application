/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cakes;

/**
 *
 * @author sipml
 */
public abstract class Cake implements Orderable {
    protected String flavour;
    protected double cost;

    public Cake(String flavour) {
        this.flavour = flavour;
    }

    public abstract double calculateCost();

    @Override
    public String toString() {
        return "Cake{flavour='" + flavour + "', cost=" + cost + '}';
    }
}
