/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cakes;
import java.time.LocalDate;
/**
 *
 * @author sipml
 */

public class Cupcake extends Cake {
    public int count;
    public int weight;
    public static final double PRICE_PER_OZ = 2.0;
    public static final int[] VALID_COUNTS = {4, 6};
    public static final int[] VALID_WEIGHTS = {1, 2, 3};

    public Cupcake(String flavour, int count, int weight) {
        super(flavour);
        if (!isValidCount(count) || !isValidWeight(weight)) {
            throw new IllegalArgumentException("Invalid count or weight");
        }
        this.count = count;
        this.weight = weight;
        calculateCost();
    }

    private boolean isValidCount(int count) {
        for (int validCount : VALID_COUNTS) {
            if (validCount == count) return true;
        }
        return false;
    }

    private boolean isValidWeight(int weight) {
        for (int validWeight : VALID_WEIGHTS) {
            if (validWeight == weight) return true;
        }
        return false;
    }

    @Override
    public double calculateCost() {
        cost = PRICE_PER_OZ * weight * count;
        return cost;
    }

    public LocalDate getExpiryDate() {
        return LocalDate.now().plusDays(3);
    }

    @Override
    public String toString() {
        return "Cupcake{flavour='" + flavour + "', count=" + count + ", weight=" + weight +
               " oz, cost=" + cost + ", expiryDate=" + getExpiryDate() + '}';
    }
}
