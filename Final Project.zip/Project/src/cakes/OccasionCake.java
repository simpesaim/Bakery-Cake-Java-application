/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cakes;

/**
 *
 * @author sipml
 */
public class OccasionCake extends Cake {
    public String occasion;
    public static final String[][] CAKE_ARRAY = {
        {"Holiday", "30"},
        {"Birthday", "40"},
        {"Anniversary", "50"},
        {"Wedding", "60"}
    };

    public OccasionCake(String flavour, String occasion) {
        super(flavour);
        this.occasion = occasion;
        setPrice(occasion);
    }

    private void setPrice(String occasion) {
        for (String[] cake : CAKE_ARRAY) {
            if (cake[0].equalsIgnoreCase(occasion)) {
                cost = Double.parseDouble(cake[1]);
                break;
            }
        }
    }

    @Override
    public double calculateCost() {
        return cost;
    }

    @Override
    public String toString() {
        return "OccasionCake{flavour='" + flavour + "', occasion='" + occasion + 
               "', cost=" + cost + '}';
    }
}
