import orders.*;

public class Tester {

    public OrderCake order; 
    public Tester() {
        // Initialize OrderCake object
        order = new OrderCake();
        // Call processOrder() 
        order.processOrder();
    }

    public void displayOrderSummary() {
        System.out.println("Order processing completed.");
    }
    
    public static void main(String[] args) {
        Tester tester = new Tester();
        tester.displayOrderSummary();
    }
}
